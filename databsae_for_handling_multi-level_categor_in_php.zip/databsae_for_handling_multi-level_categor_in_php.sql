
--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `uname`, `pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `p_cid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `name`, `p_cid`) VALUES
(15, 'Mobile', 0),
(16, 'Android', 15),
(17, 'Samsung', 16),
(18, 'Galaxy Tab', 17),
(19, 'Computer', 0),
(22, 'Desktop', 19),
(23, 'Laptop', 19),
(24, 'Windows', 15);

-- --------------------------------------------------------
 

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `category` int(255) NOT NULL,
  `color` int(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `cost` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `title`, `body`, `image`, `category`, `color`, `model`, `cost`) VALUES
(3, 'Microsoft Lumia', 'Microsoft LumiaMicrosoft LumiaMicrosoft LumiaMicrosoft Lumia', 'Nokia-Lumia-920.png', 24, 3, 'HG65', 320000),
(4, 'Samsung Galaxy', 'Samsung GalaxySamsung GalaxySamsung Galaxy', 'samsung_galaxy_tab.png', 18, 1, 'SG65', 21000),
(7, 'Hero Honda dfdfd', 'Hero Honda bikesHero Honda bikes', 'Chrysanthemum.jpg', 15, 2, 'DE43', 15000000),
(8, 'Dell Laptop', 'Dell Lapto and sample matter', 'Hydrangeas.jpg', 15, 1, 'ER43', 24000);

-- --------------------------------------------------------
 